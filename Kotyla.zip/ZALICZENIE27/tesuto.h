#ifndef PAGE_H
#define PAGE_H

#include <pgmspace.h>

const char MAIN_page[] PROGMEM = R"=====(
<!DOCTYPE html>
  <html>
    <body>
        <h1>  Twoja stara  </h1>
    </body>
  </html
)=====";

#endif